import { HttpClient, HttpRequest, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigProvider } from '../config/config';
@Injectable()
export class ProductInquiriesProvider {

  public headers = new HttpHeaders();
  public formData: FormData = new FormData();
  public responseData: any;
  private URL;

  constructor(public http: HttpClient) {
    this.headers.set('Access-Control-Allow-Origin ', '*');
    this.headers.set('Content-Type', 'application/json; charset=utf-8');
  }

  public getTypes() {
    this.URL = ConfigProvider.BASE_URL + 'product_inquiry_module/api/product_inquiry_types_api';
    this.formData.append('language_id', '1');
    return this.http.post(this.URL,
      this.formData,
      {
        headers: this.headers,
      }
    );
  }

  public send(data: any) {
    this.formData = new FormData();
    this.URL = ConfigProvider.BASE_URL + 'product_inquiry_module/api/product_inquiries_api/save';

    this.formData.append('types', JSON.stringify(data.types));
    this.formData.append('name', data.name);
    this.formData.append('email', data.email);
    this.formData.append('contact', data.contact);
    this.formData.append('inquiry', data.inquiry);
    this.formData.append('product_id', data.product_id);

    return this.http.post(this.URL,
      this.formData,
      {
        headers: this.headers,
      }
    );
  }


}
